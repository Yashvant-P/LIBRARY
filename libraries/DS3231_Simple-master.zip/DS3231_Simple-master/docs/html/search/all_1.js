var searchData=
[
  ['checkalarms',['checkAlarms',['../class_d_s3231___simple.html#ae94adee3104eb9cfefd56a6bb088ce2b',1,'DS3231_Simple']]],
  ['comparetimestamps',['compareTimestamps',['../class_d_s3231___simple.html#a97866bc1c31db33d274c38c39077b6f5',1,'DS3231_Simple']]]
];
